﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using USB_IR_Library;

namespace USB_IR_sample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void send_btn_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            byte[] code = new byte[] { 0x12, 0x08, 0x00, 0x00, 0x00, 0xFF };    // 赤外線コード
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBIR.openUSBIR(this.Handle);
                if (handle_usb_device != null)
                {
                    // USB DEVICEへ送信 パラメータ[USB DEVICEハンドル、フォーマットタイプ、送信赤外線コード、赤外線コードのビット長]
                    i_ret = USBIR.writeUSBIR(handle_usb_device, USBIR.IR_FORMAT.SONY, code, 12);
                    i_ret = USBIR.writeUSBIR(handle_usb_device, USBIR.IR_FORMAT.SONY, code, 48);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBIR.closeUSBIR(handle_usb_device);
                }
            }
        }

        private void send_ex_btn_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            byte[] code = new byte[] {  0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
                                        0x09, 0x0A, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16,
                                        0x17, 0x18, 0x19, 0x1A, 0xFF, 0x00, 0x00, 0x00,
                                        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF};    // 赤外線コード
            int i_ret = 0;

            try
            {
                // USB DEVICEオープン
                handle_usb_device = USBIR.openUSBIR(this.Handle);
                if (handle_usb_device != null)
                {
                    // USB DEVICEへ送信 パラメータ[USB DEVICEハンドル、フォーマットタイプ、送信赤外線コード、赤外線コードのビット長]
                    i_ret = USBIR.writeUSBIRex(handle_usb_device, USBIR.IR_FORMAT.AEHA, code, 64, 96);
                    //i_ret = USBIR.writeUSBIRex(handle_usb_device, USBIR.IR_FORMAT.AEHA, code, 64, 97);
                }

            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = USBIR.closeUSBIR(handle_usb_device);
                }
            }
        }
    }
}

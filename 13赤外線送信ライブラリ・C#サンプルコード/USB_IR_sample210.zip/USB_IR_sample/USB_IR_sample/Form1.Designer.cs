﻿namespace USB_IR_sample
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.send_btn = new System.Windows.Forms.Button();
            this.send_ex_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // send_btn
            // 
            this.send_btn.Location = new System.Drawing.Point(33, 22);
            this.send_btn.Name = "send_btn";
            this.send_btn.Size = new System.Drawing.Size(200, 23);
            this.send_btn.TabIndex = 0;
            this.send_btn.Text = "送信 [最大6バイト]";
            this.send_btn.UseVisualStyleBackColor = true;
            this.send_btn.Click += new System.EventHandler(this.send_btn_Click);
            // 
            // send_ex_btn
            // 
            this.send_ex_btn.Location = new System.Drawing.Point(259, 22);
            this.send_ex_btn.Name = "send_ex_btn";
            this.send_ex_btn.Size = new System.Drawing.Size(200, 23);
            this.send_ex_btn.TabIndex = 1;
            this.send_ex_btn.Text = "拡張コード 送信 [最大32バイト]";
            this.send_ex_btn.UseVisualStyleBackColor = true;
            this.send_ex_btn.Click += new System.EventHandler(this.send_ex_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 66);
            this.Controls.Add(this.send_ex_btn);
            this.Controls.Add(this.send_btn);
            this.Name = "Form1";
            this.Text = "USB赤外線リモコンキット　赤外線送信サンプル";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button send_btn;
        private System.Windows.Forms.Button send_ex_btn;
    }
}


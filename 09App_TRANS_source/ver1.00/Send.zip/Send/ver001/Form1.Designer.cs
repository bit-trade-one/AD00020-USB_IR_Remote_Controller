namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.Debug_label1 = new System.Windows.Forms.Label();
            this.Debug_label2 = new System.Windows.Forms.Label();
            this.Debug_label3 = new System.Windows.Forms.Label();
            this.Debug_label4 = new System.Windows.Forms.Label();
            this.Debug_label5 = new System.Windows.Forms.Label();
            this.Code_lbl = new System.Windows.Forms.Label();
            this.Area01_btn = new System.Windows.Forms.Button();
            this.Area02_btn = new System.Windows.Forms.Button();
            this.Area03_btn = new System.Windows.Forms.Button();
            this.Area04_btn = new System.Windows.Forms.Button();
            this.Area05_btn = new System.Windows.Forms.Button();
            this.Area06_btn = new System.Windows.Forms.Button();
            this.Area07_btn = new System.Windows.Forms.Button();
            this.Area08_btn = new System.Windows.Forms.Button();
            this.Area09_btn = new System.Windows.Forms.Button();
            this.Area10_btn = new System.Windows.Forms.Button();
            this.Area11_btn = new System.Windows.Forms.Button();
            this.Area12_btn = new System.Windows.Forms.Button();
            this.Area13_btn = new System.Windows.Forms.Button();
            this.Area14_btn = new System.Windows.Forms.Button();
            this.Area15_btn = new System.Windows.Forms.Button();
            this.Area16_btn = new System.Windows.Forms.Button();
            this.Area17_btn = new System.Windows.Forms.Button();
            this.Area18_btn = new System.Windows.Forms.Button();
            this.Area19_btn = new System.Windows.Forms.Button();
            this.Area20_btn = new System.Windows.Forms.Button();
            this.Code_20 = new System.Windows.Forms.Label();
            this.Code_19 = new System.Windows.Forms.Label();
            this.Code_18 = new System.Windows.Forms.Label();
            this.Code_17 = new System.Windows.Forms.Label();
            this.Code_16 = new System.Windows.Forms.Label();
            this.Code_15 = new System.Windows.Forms.Label();
            this.Code_14 = new System.Windows.Forms.Label();
            this.Code_13 = new System.Windows.Forms.Label();
            this.Code_12 = new System.Windows.Forms.Label();
            this.Code_11 = new System.Windows.Forms.Label();
            this.Code_10 = new System.Windows.Forms.Label();
            this.Code_09 = new System.Windows.Forms.Label();
            this.Code_08 = new System.Windows.Forms.Label();
            this.Code_07 = new System.Windows.Forms.Label();
            this.Code_06 = new System.Windows.Forms.Label();
            this.Code_05 = new System.Windows.Forms.Label();
            this.Code_04 = new System.Windows.Forms.Label();
            this.Code_03 = new System.Windows.Forms.Label();
            this.Code_02 = new System.Windows.Forms.Label();
            this.Code_01 = new System.Windows.Forms.Label();
            this.Rec_btn_03 = new System.Windows.Forms.Button();
            this.Rec_btn_02 = new System.Windows.Forms.Button();
            this.Rec_btn_01 = new System.Windows.Forms.Button();
            this.Rec_btn_06 = new System.Windows.Forms.Button();
            this.Rec_btn_05 = new System.Windows.Forms.Button();
            this.Rec_btn_04 = new System.Windows.Forms.Button();
            this.Rec_btn_09 = new System.Windows.Forms.Button();
            this.Rec_btn_08 = new System.Windows.Forms.Button();
            this.Rec_btn_07 = new System.Windows.Forms.Button();
            this.Rec_btn_12 = new System.Windows.Forms.Button();
            this.Rec_btn_11 = new System.Windows.Forms.Button();
            this.Rec_btn_10 = new System.Windows.Forms.Button();
            this.Rec_btn_15 = new System.Windows.Forms.Button();
            this.Rec_btn_14 = new System.Windows.Forms.Button();
            this.Rec_btn_13 = new System.Windows.Forms.Button();
            this.Rec_btn_18 = new System.Windows.Forms.Button();
            this.Rec_btn_17 = new System.Windows.Forms.Button();
            this.Rec_btn_16 = new System.Windows.Forms.Button();
            this.Rec_btn_20 = new System.Windows.Forms.Button();
            this.Rec_btn_19 = new System.Windows.Forms.Button();
            this.Memo01_txt = new System.Windows.Forms.TextBox();
            this.Memo02_txt = new System.Windows.Forms.TextBox();
            this.Memo03_txt = new System.Windows.Forms.TextBox();
            this.Memo04_txt = new System.Windows.Forms.TextBox();
            this.Memo05_txt = new System.Windows.Forms.TextBox();
            this.Memo06_txt = new System.Windows.Forms.TextBox();
            this.Memo07_txt = new System.Windows.Forms.TextBox();
            this.Memo08_txt = new System.Windows.Forms.TextBox();
            this.Memo09_txt = new System.Windows.Forms.TextBox();
            this.Memo10_txt = new System.Windows.Forms.TextBox();
            this.Memo11_txt = new System.Windows.Forms.TextBox();
            this.Memo12_txt = new System.Windows.Forms.TextBox();
            this.Memo13_txt = new System.Windows.Forms.TextBox();
            this.Memo14_txt = new System.Windows.Forms.TextBox();
            this.Memo15_txt = new System.Windows.Forms.TextBox();
            this.Memo16_txt = new System.Windows.Forms.TextBox();
            this.Memo17_txt = new System.Windows.Forms.TextBox();
            this.Memo18_txt = new System.Windows.Forms.TextBox();
            this.Memo19_txt = new System.Windows.Forms.TextBox();
            this.Memo20_txt = new System.Windows.Forms.TextBox();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.BackGround_pb = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BackGround_pb)).BeginInit();
            this.SuspendLayout();
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(757, 548);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 117;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(19, 548);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(282, 12);
            this.StatusBox_lbl2.TabIndex = 118;
            this.StatusBox_lbl2.Text = "USB�ԊO�������R���L�b�g, Configuration Tool�N�����܂���";
            // 
            // Debug_label1
            // 
            this.Debug_label1.AutoSize = true;
            this.Debug_label1.Location = new System.Drawing.Point(708, 415);
            this.Debug_label1.Name = "Debug_label1";
            this.Debug_label1.Size = new System.Drawing.Size(41, 12);
            this.Debug_label1.TabIndex = 164;
            this.Debug_label1.Text = "debug1";
            this.Debug_label1.Visible = false;
            // 
            // Debug_label2
            // 
            this.Debug_label2.AutoSize = true;
            this.Debug_label2.Location = new System.Drawing.Point(708, 427);
            this.Debug_label2.Name = "Debug_label2";
            this.Debug_label2.Size = new System.Drawing.Size(41, 12);
            this.Debug_label2.TabIndex = 165;
            this.Debug_label2.Text = "debug1";
            this.Debug_label2.Visible = false;
            // 
            // Debug_label3
            // 
            this.Debug_label3.AutoSize = true;
            this.Debug_label3.Location = new System.Drawing.Point(708, 439);
            this.Debug_label3.Name = "Debug_label3";
            this.Debug_label3.Size = new System.Drawing.Size(41, 12);
            this.Debug_label3.TabIndex = 166;
            this.Debug_label3.Text = "debug1";
            this.Debug_label3.Visible = false;
            // 
            // Debug_label4
            // 
            this.Debug_label4.AutoSize = true;
            this.Debug_label4.Location = new System.Drawing.Point(708, 455);
            this.Debug_label4.Name = "Debug_label4";
            this.Debug_label4.Size = new System.Drawing.Size(41, 12);
            this.Debug_label4.TabIndex = 167;
            this.Debug_label4.Text = "debug1";
            this.Debug_label4.Visible = false;
            // 
            // Debug_label5
            // 
            this.Debug_label5.AutoSize = true;
            this.Debug_label5.Location = new System.Drawing.Point(708, 467);
            this.Debug_label5.Name = "Debug_label5";
            this.Debug_label5.Size = new System.Drawing.Size(41, 12);
            this.Debug_label5.TabIndex = 168;
            this.Debug_label5.Text = "debug1";
            this.Debug_label5.Visible = false;
            // 
            // Code_lbl
            // 
            this.Code_lbl.AutoSize = true;
            this.Code_lbl.Location = new System.Drawing.Point(83, 100);
            this.Code_lbl.Name = "Code_lbl";
            this.Code_lbl.Size = new System.Drawing.Size(0, 12);
            this.Code_lbl.TabIndex = 172;
            // 
            // Area01_btn
            // 
            this.Area01_btn.Enabled = false;
            this.Area01_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area01_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area01_btn.Location = new System.Drawing.Point(617, 25);
            this.Area01_btn.Name = "Area01_btn";
            this.Area01_btn.Size = new System.Drawing.Size(85, 19);
            this.Area01_btn.TabIndex = 173;
            this.Area01_btn.Tag = "1";
            this.Area01_btn.Text = "�ԊO�����M";
            this.Area01_btn.UseVisualStyleBackColor = true;
            this.Area01_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area02_btn
            // 
            this.Area02_btn.Enabled = false;
            this.Area02_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area02_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area02_btn.Location = new System.Drawing.Point(617, 51);
            this.Area02_btn.Name = "Area02_btn";
            this.Area02_btn.Size = new System.Drawing.Size(85, 19);
            this.Area02_btn.TabIndex = 174;
            this.Area02_btn.Tag = "2";
            this.Area02_btn.Text = "�ԊO�����M";
            this.Area02_btn.UseVisualStyleBackColor = true;
            this.Area02_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area03_btn
            // 
            this.Area03_btn.Enabled = false;
            this.Area03_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area03_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area03_btn.Location = new System.Drawing.Point(617, 77);
            this.Area03_btn.Name = "Area03_btn";
            this.Area03_btn.Size = new System.Drawing.Size(85, 19);
            this.Area03_btn.TabIndex = 175;
            this.Area03_btn.Tag = "3";
            this.Area03_btn.Text = "�ԊO�����M";
            this.Area03_btn.UseVisualStyleBackColor = true;
            this.Area03_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area04_btn
            // 
            this.Area04_btn.Enabled = false;
            this.Area04_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area04_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area04_btn.Location = new System.Drawing.Point(617, 103);
            this.Area04_btn.Name = "Area04_btn";
            this.Area04_btn.Size = new System.Drawing.Size(85, 19);
            this.Area04_btn.TabIndex = 194;
            this.Area04_btn.Tag = "4";
            this.Area04_btn.Text = "�ԊO�����M";
            this.Area04_btn.UseVisualStyleBackColor = true;
            this.Area04_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area05_btn
            // 
            this.Area05_btn.Enabled = false;
            this.Area05_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area05_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area05_btn.Location = new System.Drawing.Point(617, 129);
            this.Area05_btn.Name = "Area05_btn";
            this.Area05_btn.Size = new System.Drawing.Size(85, 19);
            this.Area05_btn.TabIndex = 195;
            this.Area05_btn.Tag = "5";
            this.Area05_btn.Text = "�ԊO�����M";
            this.Area05_btn.UseVisualStyleBackColor = true;
            this.Area05_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area06_btn
            // 
            this.Area06_btn.Enabled = false;
            this.Area06_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area06_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area06_btn.Location = new System.Drawing.Point(617, 155);
            this.Area06_btn.Name = "Area06_btn";
            this.Area06_btn.Size = new System.Drawing.Size(85, 19);
            this.Area06_btn.TabIndex = 196;
            this.Area06_btn.Tag = "6";
            this.Area06_btn.Text = "�ԊO�����M";
            this.Area06_btn.UseVisualStyleBackColor = true;
            this.Area06_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area07_btn
            // 
            this.Area07_btn.Enabled = false;
            this.Area07_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area07_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area07_btn.Location = new System.Drawing.Point(617, 181);
            this.Area07_btn.Name = "Area07_btn";
            this.Area07_btn.Size = new System.Drawing.Size(85, 19);
            this.Area07_btn.TabIndex = 197;
            this.Area07_btn.Tag = "7";
            this.Area07_btn.Text = "�ԊO�����M";
            this.Area07_btn.UseVisualStyleBackColor = true;
            this.Area07_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area08_btn
            // 
            this.Area08_btn.Enabled = false;
            this.Area08_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area08_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area08_btn.Location = new System.Drawing.Point(617, 207);
            this.Area08_btn.Name = "Area08_btn";
            this.Area08_btn.Size = new System.Drawing.Size(85, 19);
            this.Area08_btn.TabIndex = 198;
            this.Area08_btn.Tag = "8";
            this.Area08_btn.Text = "�ԊO�����M";
            this.Area08_btn.UseVisualStyleBackColor = true;
            this.Area08_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area09_btn
            // 
            this.Area09_btn.Enabled = false;
            this.Area09_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area09_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area09_btn.Location = new System.Drawing.Point(617, 233);
            this.Area09_btn.Name = "Area09_btn";
            this.Area09_btn.Size = new System.Drawing.Size(85, 19);
            this.Area09_btn.TabIndex = 199;
            this.Area09_btn.Tag = "9";
            this.Area09_btn.Text = "�ԊO�����M";
            this.Area09_btn.UseVisualStyleBackColor = true;
            this.Area09_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area10_btn
            // 
            this.Area10_btn.Enabled = false;
            this.Area10_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area10_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area10_btn.Location = new System.Drawing.Point(617, 259);
            this.Area10_btn.Name = "Area10_btn";
            this.Area10_btn.Size = new System.Drawing.Size(85, 19);
            this.Area10_btn.TabIndex = 200;
            this.Area10_btn.Tag = "10";
            this.Area10_btn.Text = "�ԊO�����M";
            this.Area10_btn.UseVisualStyleBackColor = true;
            this.Area10_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area11_btn
            // 
            this.Area11_btn.Enabled = false;
            this.Area11_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area11_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area11_btn.Location = new System.Drawing.Point(617, 285);
            this.Area11_btn.Name = "Area11_btn";
            this.Area11_btn.Size = new System.Drawing.Size(85, 19);
            this.Area11_btn.TabIndex = 201;
            this.Area11_btn.Tag = "11";
            this.Area11_btn.Text = "�ԊO�����M";
            this.Area11_btn.UseVisualStyleBackColor = true;
            this.Area11_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area12_btn
            // 
            this.Area12_btn.Enabled = false;
            this.Area12_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area12_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area12_btn.Location = new System.Drawing.Point(617, 311);
            this.Area12_btn.Name = "Area12_btn";
            this.Area12_btn.Size = new System.Drawing.Size(85, 19);
            this.Area12_btn.TabIndex = 202;
            this.Area12_btn.Tag = "12";
            this.Area12_btn.Text = "�ԊO�����M";
            this.Area12_btn.UseVisualStyleBackColor = true;
            this.Area12_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area13_btn
            // 
            this.Area13_btn.Enabled = false;
            this.Area13_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area13_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area13_btn.Location = new System.Drawing.Point(617, 337);
            this.Area13_btn.Name = "Area13_btn";
            this.Area13_btn.Size = new System.Drawing.Size(85, 19);
            this.Area13_btn.TabIndex = 203;
            this.Area13_btn.Tag = "13";
            this.Area13_btn.Text = "�ԊO�����M";
            this.Area13_btn.UseVisualStyleBackColor = true;
            this.Area13_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area14_btn
            // 
            this.Area14_btn.Enabled = false;
            this.Area14_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area14_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area14_btn.Location = new System.Drawing.Point(617, 363);
            this.Area14_btn.Name = "Area14_btn";
            this.Area14_btn.Size = new System.Drawing.Size(85, 19);
            this.Area14_btn.TabIndex = 204;
            this.Area14_btn.Tag = "14";
            this.Area14_btn.Text = "�ԊO�����M";
            this.Area14_btn.UseVisualStyleBackColor = true;
            this.Area14_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area15_btn
            // 
            this.Area15_btn.Enabled = false;
            this.Area15_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area15_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area15_btn.Location = new System.Drawing.Point(617, 389);
            this.Area15_btn.Name = "Area15_btn";
            this.Area15_btn.Size = new System.Drawing.Size(85, 19);
            this.Area15_btn.TabIndex = 205;
            this.Area15_btn.Tag = "15";
            this.Area15_btn.Text = "�ԊO�����M";
            this.Area15_btn.UseVisualStyleBackColor = true;
            this.Area15_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area16_btn
            // 
            this.Area16_btn.Enabled = false;
            this.Area16_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area16_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area16_btn.Location = new System.Drawing.Point(617, 415);
            this.Area16_btn.Name = "Area16_btn";
            this.Area16_btn.Size = new System.Drawing.Size(85, 19);
            this.Area16_btn.TabIndex = 206;
            this.Area16_btn.Tag = "16";
            this.Area16_btn.Text = "�ԊO�����M";
            this.Area16_btn.UseVisualStyleBackColor = true;
            this.Area16_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area17_btn
            // 
            this.Area17_btn.Enabled = false;
            this.Area17_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area17_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area17_btn.Location = new System.Drawing.Point(617, 441);
            this.Area17_btn.Name = "Area17_btn";
            this.Area17_btn.Size = new System.Drawing.Size(85, 19);
            this.Area17_btn.TabIndex = 207;
            this.Area17_btn.Tag = "17";
            this.Area17_btn.Text = "�ԊO�����M";
            this.Area17_btn.UseVisualStyleBackColor = true;
            this.Area17_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area18_btn
            // 
            this.Area18_btn.Enabled = false;
            this.Area18_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area18_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area18_btn.Location = new System.Drawing.Point(617, 467);
            this.Area18_btn.Name = "Area18_btn";
            this.Area18_btn.Size = new System.Drawing.Size(85, 19);
            this.Area18_btn.TabIndex = 208;
            this.Area18_btn.Tag = "18";
            this.Area18_btn.Text = "�ԊO�����M";
            this.Area18_btn.UseVisualStyleBackColor = true;
            this.Area18_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area19_btn
            // 
            this.Area19_btn.Enabled = false;
            this.Area19_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area19_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area19_btn.Location = new System.Drawing.Point(617, 493);
            this.Area19_btn.Name = "Area19_btn";
            this.Area19_btn.Size = new System.Drawing.Size(85, 19);
            this.Area19_btn.TabIndex = 209;
            this.Area19_btn.Tag = "19";
            this.Area19_btn.Text = "�ԊO�����M";
            this.Area19_btn.UseVisualStyleBackColor = true;
            this.Area19_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Area20_btn
            // 
            this.Area20_btn.Enabled = false;
            this.Area20_btn.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Area20_btn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Area20_btn.Location = new System.Drawing.Point(617, 519);
            this.Area20_btn.Name = "Area20_btn";
            this.Area20_btn.Size = new System.Drawing.Size(85, 19);
            this.Area20_btn.TabIndex = 210;
            this.Area20_btn.Tag = "20";
            this.Area20_btn.Text = "�ԊO�����M";
            this.Area20_btn.UseVisualStyleBackColor = true;
            this.Area20_btn.Click += new System.EventHandler(this.Area_Button_Click);
            // 
            // Code_20
            // 
            this.Code_20.AutoSize = true;
            this.Code_20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_20.Enabled = false;
            this.Code_20.ForeColor = System.Drawing.Color.White;
            this.Code_20.Location = new System.Drawing.Point(189, 523);
            this.Code_20.Name = "Code_20";
            this.Code_20.Size = new System.Drawing.Size(45, 12);
            this.Code_20.TabIndex = 250;
            this.Code_20.Tag = "20";
            this.Code_20.Text = "code 20";
            // 
            // Code_19
            // 
            this.Code_19.AutoSize = true;
            this.Code_19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_19.Enabled = false;
            this.Code_19.ForeColor = System.Drawing.Color.White;
            this.Code_19.Location = new System.Drawing.Point(189, 497);
            this.Code_19.Name = "Code_19";
            this.Code_19.Size = new System.Drawing.Size(45, 12);
            this.Code_19.TabIndex = 249;
            this.Code_19.Tag = "19";
            this.Code_19.Text = "code 19";
            // 
            // Code_18
            // 
            this.Code_18.AutoSize = true;
            this.Code_18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_18.Enabled = false;
            this.Code_18.ForeColor = System.Drawing.Color.White;
            this.Code_18.Location = new System.Drawing.Point(189, 471);
            this.Code_18.Name = "Code_18";
            this.Code_18.Size = new System.Drawing.Size(45, 12);
            this.Code_18.TabIndex = 248;
            this.Code_18.Tag = "18";
            this.Code_18.Text = "code 18";
            // 
            // Code_17
            // 
            this.Code_17.AutoSize = true;
            this.Code_17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_17.Enabled = false;
            this.Code_17.ForeColor = System.Drawing.Color.White;
            this.Code_17.Location = new System.Drawing.Point(189, 445);
            this.Code_17.Name = "Code_17";
            this.Code_17.Size = new System.Drawing.Size(45, 12);
            this.Code_17.TabIndex = 247;
            this.Code_17.Tag = "17";
            this.Code_17.Text = "code 17";
            // 
            // Code_16
            // 
            this.Code_16.AutoSize = true;
            this.Code_16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_16.Enabled = false;
            this.Code_16.ForeColor = System.Drawing.Color.White;
            this.Code_16.Location = new System.Drawing.Point(189, 419);
            this.Code_16.Name = "Code_16";
            this.Code_16.Size = new System.Drawing.Size(45, 12);
            this.Code_16.TabIndex = 246;
            this.Code_16.Tag = "16";
            this.Code_16.Text = "code 16";
            // 
            // Code_15
            // 
            this.Code_15.AutoSize = true;
            this.Code_15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_15.Enabled = false;
            this.Code_15.ForeColor = System.Drawing.Color.White;
            this.Code_15.Location = new System.Drawing.Point(189, 393);
            this.Code_15.Name = "Code_15";
            this.Code_15.Size = new System.Drawing.Size(45, 12);
            this.Code_15.TabIndex = 245;
            this.Code_15.Tag = "15";
            this.Code_15.Text = "code 15";
            // 
            // Code_14
            // 
            this.Code_14.AutoSize = true;
            this.Code_14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_14.Enabled = false;
            this.Code_14.ForeColor = System.Drawing.Color.White;
            this.Code_14.Location = new System.Drawing.Point(189, 367);
            this.Code_14.Name = "Code_14";
            this.Code_14.Size = new System.Drawing.Size(45, 12);
            this.Code_14.TabIndex = 244;
            this.Code_14.Tag = "14";
            this.Code_14.Text = "code 14";
            // 
            // Code_13
            // 
            this.Code_13.AutoSize = true;
            this.Code_13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_13.Enabled = false;
            this.Code_13.ForeColor = System.Drawing.Color.White;
            this.Code_13.Location = new System.Drawing.Point(189, 341);
            this.Code_13.Name = "Code_13";
            this.Code_13.Size = new System.Drawing.Size(45, 12);
            this.Code_13.TabIndex = 243;
            this.Code_13.Tag = "13";
            this.Code_13.Text = "code 13";
            // 
            // Code_12
            // 
            this.Code_12.AutoSize = true;
            this.Code_12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_12.Enabled = false;
            this.Code_12.ForeColor = System.Drawing.Color.White;
            this.Code_12.Location = new System.Drawing.Point(189, 315);
            this.Code_12.Name = "Code_12";
            this.Code_12.Size = new System.Drawing.Size(45, 12);
            this.Code_12.TabIndex = 242;
            this.Code_12.Tag = "12";
            this.Code_12.Text = "code 12";
            // 
            // Code_11
            // 
            this.Code_11.AutoSize = true;
            this.Code_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_11.Enabled = false;
            this.Code_11.ForeColor = System.Drawing.Color.White;
            this.Code_11.Location = new System.Drawing.Point(189, 289);
            this.Code_11.Name = "Code_11";
            this.Code_11.Size = new System.Drawing.Size(45, 12);
            this.Code_11.TabIndex = 241;
            this.Code_11.Tag = "11";
            this.Code_11.Text = "code 11";
            // 
            // Code_10
            // 
            this.Code_10.AutoSize = true;
            this.Code_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_10.Enabled = false;
            this.Code_10.ForeColor = System.Drawing.Color.White;
            this.Code_10.Location = new System.Drawing.Point(189, 263);
            this.Code_10.Name = "Code_10";
            this.Code_10.Size = new System.Drawing.Size(45, 12);
            this.Code_10.TabIndex = 240;
            this.Code_10.Tag = "10";
            this.Code_10.Text = "code 10";
            // 
            // Code_09
            // 
            this.Code_09.AutoSize = true;
            this.Code_09.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_09.Enabled = false;
            this.Code_09.ForeColor = System.Drawing.Color.White;
            this.Code_09.Location = new System.Drawing.Point(189, 237);
            this.Code_09.Name = "Code_09";
            this.Code_09.Size = new System.Drawing.Size(45, 12);
            this.Code_09.TabIndex = 239;
            this.Code_09.Tag = "9";
            this.Code_09.Text = "code 09";
            // 
            // Code_08
            // 
            this.Code_08.AutoSize = true;
            this.Code_08.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_08.Enabled = false;
            this.Code_08.ForeColor = System.Drawing.Color.White;
            this.Code_08.Location = new System.Drawing.Point(189, 211);
            this.Code_08.Name = "Code_08";
            this.Code_08.Size = new System.Drawing.Size(45, 12);
            this.Code_08.TabIndex = 238;
            this.Code_08.Tag = "8";
            this.Code_08.Text = "code 08";
            // 
            // Code_07
            // 
            this.Code_07.AutoSize = true;
            this.Code_07.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_07.Enabled = false;
            this.Code_07.ForeColor = System.Drawing.Color.White;
            this.Code_07.Location = new System.Drawing.Point(189, 185);
            this.Code_07.Name = "Code_07";
            this.Code_07.Size = new System.Drawing.Size(45, 12);
            this.Code_07.TabIndex = 237;
            this.Code_07.Tag = "7";
            this.Code_07.Text = "code 07";
            // 
            // Code_06
            // 
            this.Code_06.AutoSize = true;
            this.Code_06.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_06.Enabled = false;
            this.Code_06.ForeColor = System.Drawing.Color.White;
            this.Code_06.Location = new System.Drawing.Point(189, 159);
            this.Code_06.Name = "Code_06";
            this.Code_06.Size = new System.Drawing.Size(45, 12);
            this.Code_06.TabIndex = 236;
            this.Code_06.Tag = "6";
            this.Code_06.Text = "code 06";
            // 
            // Code_05
            // 
            this.Code_05.AutoSize = true;
            this.Code_05.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_05.Enabled = false;
            this.Code_05.ForeColor = System.Drawing.Color.White;
            this.Code_05.Location = new System.Drawing.Point(189, 133);
            this.Code_05.Name = "Code_05";
            this.Code_05.Size = new System.Drawing.Size(45, 12);
            this.Code_05.TabIndex = 235;
            this.Code_05.Tag = "5";
            this.Code_05.Text = "code 05";
            // 
            // Code_04
            // 
            this.Code_04.AutoSize = true;
            this.Code_04.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_04.Enabled = false;
            this.Code_04.ForeColor = System.Drawing.Color.White;
            this.Code_04.Location = new System.Drawing.Point(189, 107);
            this.Code_04.Name = "Code_04";
            this.Code_04.Size = new System.Drawing.Size(45, 12);
            this.Code_04.TabIndex = 234;
            this.Code_04.Tag = "4";
            this.Code_04.Text = "code 04";
            // 
            // Code_03
            // 
            this.Code_03.AutoSize = true;
            this.Code_03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_03.Enabled = false;
            this.Code_03.ForeColor = System.Drawing.Color.White;
            this.Code_03.Location = new System.Drawing.Point(189, 81);
            this.Code_03.Name = "Code_03";
            this.Code_03.Size = new System.Drawing.Size(45, 12);
            this.Code_03.TabIndex = 233;
            this.Code_03.Tag = "3";
            this.Code_03.Text = "code 03";
            // 
            // Code_02
            // 
            this.Code_02.AutoSize = true;
            this.Code_02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_02.Enabled = false;
            this.Code_02.ForeColor = System.Drawing.Color.White;
            this.Code_02.Location = new System.Drawing.Point(189, 55);
            this.Code_02.Name = "Code_02";
            this.Code_02.Size = new System.Drawing.Size(45, 12);
            this.Code_02.TabIndex = 232;
            this.Code_02.Tag = "2";
            this.Code_02.Text = "code 02";
            // 
            // Code_01
            // 
            this.Code_01.AutoSize = true;
            this.Code_01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(175)))), ((int)(((byte)(175)))));
            this.Code_01.Enabled = false;
            this.Code_01.ForeColor = System.Drawing.Color.White;
            this.Code_01.Location = new System.Drawing.Point(189, 29);
            this.Code_01.Name = "Code_01";
            this.Code_01.Size = new System.Drawing.Size(45, 12);
            this.Code_01.TabIndex = 231;
            this.Code_01.Tag = "1";
            this.Code_01.Text = "code 01";
            // 
            // Rec_btn_03
            // 
            this.Rec_btn_03.Enabled = false;
            this.Rec_btn_03.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_03.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_03.Location = new System.Drawing.Point(86, 77);
            this.Rec_btn_03.Name = "Rec_btn_03";
            this.Rec_btn_03.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_03.TabIndex = 253;
            this.Rec_btn_03.Tag = "3";
            this.Rec_btn_03.Text = "RECORD";
            this.Rec_btn_03.UseVisualStyleBackColor = true;
            this.Rec_btn_03.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_02
            // 
            this.Rec_btn_02.Enabled = false;
            this.Rec_btn_02.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_02.Location = new System.Drawing.Point(86, 51);
            this.Rec_btn_02.Name = "Rec_btn_02";
            this.Rec_btn_02.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_02.TabIndex = 252;
            this.Rec_btn_02.Tag = "2";
            this.Rec_btn_02.Text = "RECORD";
            this.Rec_btn_02.UseVisualStyleBackColor = true;
            this.Rec_btn_02.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_01
            // 
            this.Rec_btn_01.Enabled = false;
            this.Rec_btn_01.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_01.Location = new System.Drawing.Point(86, 25);
            this.Rec_btn_01.Name = "Rec_btn_01";
            this.Rec_btn_01.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_01.TabIndex = 251;
            this.Rec_btn_01.Tag = "1";
            this.Rec_btn_01.Text = "RECORD";
            this.Rec_btn_01.UseVisualStyleBackColor = true;
            this.Rec_btn_01.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_06
            // 
            this.Rec_btn_06.Enabled = false;
            this.Rec_btn_06.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_06.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_06.Location = new System.Drawing.Point(86, 155);
            this.Rec_btn_06.Name = "Rec_btn_06";
            this.Rec_btn_06.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_06.TabIndex = 256;
            this.Rec_btn_06.Tag = "6";
            this.Rec_btn_06.Text = "RECORD";
            this.Rec_btn_06.UseVisualStyleBackColor = true;
            this.Rec_btn_06.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_05
            // 
            this.Rec_btn_05.Enabled = false;
            this.Rec_btn_05.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_05.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_05.Location = new System.Drawing.Point(86, 129);
            this.Rec_btn_05.Name = "Rec_btn_05";
            this.Rec_btn_05.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_05.TabIndex = 255;
            this.Rec_btn_05.Tag = "5";
            this.Rec_btn_05.Text = "RECORD";
            this.Rec_btn_05.UseVisualStyleBackColor = true;
            this.Rec_btn_05.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_04
            // 
            this.Rec_btn_04.Enabled = false;
            this.Rec_btn_04.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_04.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_04.Location = new System.Drawing.Point(86, 103);
            this.Rec_btn_04.Name = "Rec_btn_04";
            this.Rec_btn_04.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_04.TabIndex = 254;
            this.Rec_btn_04.Tag = "4";
            this.Rec_btn_04.Text = "RECORD";
            this.Rec_btn_04.UseVisualStyleBackColor = true;
            this.Rec_btn_04.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_09
            // 
            this.Rec_btn_09.Enabled = false;
            this.Rec_btn_09.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_09.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_09.Location = new System.Drawing.Point(86, 233);
            this.Rec_btn_09.Name = "Rec_btn_09";
            this.Rec_btn_09.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_09.TabIndex = 259;
            this.Rec_btn_09.Tag = "9";
            this.Rec_btn_09.Text = "RECORD";
            this.Rec_btn_09.UseVisualStyleBackColor = true;
            this.Rec_btn_09.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_08
            // 
            this.Rec_btn_08.Enabled = false;
            this.Rec_btn_08.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_08.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_08.Location = new System.Drawing.Point(86, 207);
            this.Rec_btn_08.Name = "Rec_btn_08";
            this.Rec_btn_08.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_08.TabIndex = 258;
            this.Rec_btn_08.Tag = "8";
            this.Rec_btn_08.Text = "RECORD";
            this.Rec_btn_08.UseVisualStyleBackColor = true;
            this.Rec_btn_08.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_07
            // 
            this.Rec_btn_07.Enabled = false;
            this.Rec_btn_07.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_07.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_07.Location = new System.Drawing.Point(86, 181);
            this.Rec_btn_07.Name = "Rec_btn_07";
            this.Rec_btn_07.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_07.TabIndex = 257;
            this.Rec_btn_07.Tag = "7";
            this.Rec_btn_07.Text = "RECORD";
            this.Rec_btn_07.UseVisualStyleBackColor = true;
            this.Rec_btn_07.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_12
            // 
            this.Rec_btn_12.Enabled = false;
            this.Rec_btn_12.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_12.Location = new System.Drawing.Point(86, 311);
            this.Rec_btn_12.Name = "Rec_btn_12";
            this.Rec_btn_12.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_12.TabIndex = 262;
            this.Rec_btn_12.Tag = "12";
            this.Rec_btn_12.Text = "RECORD";
            this.Rec_btn_12.UseVisualStyleBackColor = true;
            this.Rec_btn_12.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_11
            // 
            this.Rec_btn_11.Enabled = false;
            this.Rec_btn_11.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_11.Location = new System.Drawing.Point(86, 285);
            this.Rec_btn_11.Name = "Rec_btn_11";
            this.Rec_btn_11.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_11.TabIndex = 261;
            this.Rec_btn_11.Tag = "11";
            this.Rec_btn_11.Text = "RECORD";
            this.Rec_btn_11.UseVisualStyleBackColor = true;
            this.Rec_btn_11.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_10
            // 
            this.Rec_btn_10.Enabled = false;
            this.Rec_btn_10.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_10.Location = new System.Drawing.Point(86, 259);
            this.Rec_btn_10.Name = "Rec_btn_10";
            this.Rec_btn_10.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_10.TabIndex = 260;
            this.Rec_btn_10.Tag = "10";
            this.Rec_btn_10.Text = "RECORD";
            this.Rec_btn_10.UseVisualStyleBackColor = true;
            this.Rec_btn_10.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_15
            // 
            this.Rec_btn_15.Enabled = false;
            this.Rec_btn_15.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_15.Location = new System.Drawing.Point(86, 389);
            this.Rec_btn_15.Name = "Rec_btn_15";
            this.Rec_btn_15.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_15.TabIndex = 265;
            this.Rec_btn_15.Tag = "15";
            this.Rec_btn_15.Text = "RECORD";
            this.Rec_btn_15.UseVisualStyleBackColor = true;
            this.Rec_btn_15.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_14
            // 
            this.Rec_btn_14.Enabled = false;
            this.Rec_btn_14.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_14.Location = new System.Drawing.Point(86, 363);
            this.Rec_btn_14.Name = "Rec_btn_14";
            this.Rec_btn_14.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_14.TabIndex = 264;
            this.Rec_btn_14.Tag = "14";
            this.Rec_btn_14.Text = "RECORD";
            this.Rec_btn_14.UseVisualStyleBackColor = true;
            this.Rec_btn_14.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_13
            // 
            this.Rec_btn_13.Enabled = false;
            this.Rec_btn_13.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_13.Location = new System.Drawing.Point(86, 337);
            this.Rec_btn_13.Name = "Rec_btn_13";
            this.Rec_btn_13.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_13.TabIndex = 263;
            this.Rec_btn_13.Tag = "13";
            this.Rec_btn_13.Text = "RECORD";
            this.Rec_btn_13.UseVisualStyleBackColor = true;
            this.Rec_btn_13.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_18
            // 
            this.Rec_btn_18.Enabled = false;
            this.Rec_btn_18.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_18.Location = new System.Drawing.Point(86, 467);
            this.Rec_btn_18.Name = "Rec_btn_18";
            this.Rec_btn_18.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_18.TabIndex = 268;
            this.Rec_btn_18.Tag = "18";
            this.Rec_btn_18.Text = "RECORD";
            this.Rec_btn_18.UseVisualStyleBackColor = true;
            this.Rec_btn_18.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_17
            // 
            this.Rec_btn_17.Enabled = false;
            this.Rec_btn_17.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_17.Location = new System.Drawing.Point(86, 441);
            this.Rec_btn_17.Name = "Rec_btn_17";
            this.Rec_btn_17.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_17.TabIndex = 267;
            this.Rec_btn_17.Tag = "17";
            this.Rec_btn_17.Text = "RECORD";
            this.Rec_btn_17.UseVisualStyleBackColor = true;
            this.Rec_btn_17.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_16
            // 
            this.Rec_btn_16.Enabled = false;
            this.Rec_btn_16.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_16.Location = new System.Drawing.Point(86, 415);
            this.Rec_btn_16.Name = "Rec_btn_16";
            this.Rec_btn_16.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_16.TabIndex = 266;
            this.Rec_btn_16.Tag = "16";
            this.Rec_btn_16.Text = "RECORD";
            this.Rec_btn_16.UseVisualStyleBackColor = true;
            this.Rec_btn_16.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_20
            // 
            this.Rec_btn_20.Enabled = false;
            this.Rec_btn_20.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_20.Location = new System.Drawing.Point(86, 519);
            this.Rec_btn_20.Name = "Rec_btn_20";
            this.Rec_btn_20.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_20.TabIndex = 270;
            this.Rec_btn_20.Tag = "20";
            this.Rec_btn_20.Text = "RECORD";
            this.Rec_btn_20.UseVisualStyleBackColor = true;
            this.Rec_btn_20.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Rec_btn_19
            // 
            this.Rec_btn_19.Enabled = false;
            this.Rec_btn_19.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Rec_btn_19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Rec_btn_19.Location = new System.Drawing.Point(86, 493);
            this.Rec_btn_19.Name = "Rec_btn_19";
            this.Rec_btn_19.Size = new System.Drawing.Size(73, 19);
            this.Rec_btn_19.TabIndex = 269;
            this.Rec_btn_19.Tag = "19";
            this.Rec_btn_19.Text = "RECORD";
            this.Rec_btn_19.UseVisualStyleBackColor = true;
            this.Rec_btn_19.Click += new System.EventHandler(this.Receive_btn_Click);
            // 
            // Memo01_txt
            // 
            this.Memo01_txt.Enabled = false;
            this.Memo01_txt.Location = new System.Drawing.Point(332, 25);
            this.Memo01_txt.Name = "Memo01_txt";
            this.Memo01_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo01_txt.TabIndex = 271;
            this.Memo01_txt.Tag = "1";
            this.Memo01_txt.Text = "memo 01";
            this.Memo01_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo02_txt
            // 
            this.Memo02_txt.Enabled = false;
            this.Memo02_txt.Location = new System.Drawing.Point(332, 51);
            this.Memo02_txt.Name = "Memo02_txt";
            this.Memo02_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo02_txt.TabIndex = 272;
            this.Memo02_txt.Tag = "2";
            this.Memo02_txt.Text = "memo 02";
            this.Memo02_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo03_txt
            // 
            this.Memo03_txt.Enabled = false;
            this.Memo03_txt.Location = new System.Drawing.Point(332, 77);
            this.Memo03_txt.Name = "Memo03_txt";
            this.Memo03_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo03_txt.TabIndex = 273;
            this.Memo03_txt.Tag = "3";
            this.Memo03_txt.Text = "memo 03";
            this.Memo03_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo04_txt
            // 
            this.Memo04_txt.Enabled = false;
            this.Memo04_txt.Location = new System.Drawing.Point(332, 103);
            this.Memo04_txt.Name = "Memo04_txt";
            this.Memo04_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo04_txt.TabIndex = 274;
            this.Memo04_txt.Tag = "4";
            this.Memo04_txt.Text = "memo 04";
            this.Memo04_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo05_txt
            // 
            this.Memo05_txt.Enabled = false;
            this.Memo05_txt.Location = new System.Drawing.Point(332, 129);
            this.Memo05_txt.Name = "Memo05_txt";
            this.Memo05_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo05_txt.TabIndex = 275;
            this.Memo05_txt.Tag = "5";
            this.Memo05_txt.Text = "memo 05";
            this.Memo05_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo06_txt
            // 
            this.Memo06_txt.Enabled = false;
            this.Memo06_txt.Location = new System.Drawing.Point(332, 155);
            this.Memo06_txt.Name = "Memo06_txt";
            this.Memo06_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo06_txt.TabIndex = 276;
            this.Memo06_txt.Tag = "6";
            this.Memo06_txt.Text = "memo 06";
            this.Memo06_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo07_txt
            // 
            this.Memo07_txt.Enabled = false;
            this.Memo07_txt.Location = new System.Drawing.Point(332, 181);
            this.Memo07_txt.Name = "Memo07_txt";
            this.Memo07_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo07_txt.TabIndex = 277;
            this.Memo07_txt.Tag = "7";
            this.Memo07_txt.Text = "memo 07";
            this.Memo07_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo08_txt
            // 
            this.Memo08_txt.Enabled = false;
            this.Memo08_txt.Location = new System.Drawing.Point(332, 207);
            this.Memo08_txt.Name = "Memo08_txt";
            this.Memo08_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo08_txt.TabIndex = 278;
            this.Memo08_txt.Tag = "8";
            this.Memo08_txt.Text = "memo 08";
            this.Memo08_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo09_txt
            // 
            this.Memo09_txt.Enabled = false;
            this.Memo09_txt.Location = new System.Drawing.Point(332, 233);
            this.Memo09_txt.Name = "Memo09_txt";
            this.Memo09_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo09_txt.TabIndex = 279;
            this.Memo09_txt.Tag = "9";
            this.Memo09_txt.Text = "memo 09";
            this.Memo09_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo10_txt
            // 
            this.Memo10_txt.Enabled = false;
            this.Memo10_txt.Location = new System.Drawing.Point(332, 259);
            this.Memo10_txt.Name = "Memo10_txt";
            this.Memo10_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo10_txt.TabIndex = 280;
            this.Memo10_txt.Tag = "10";
            this.Memo10_txt.Text = "memo 10";
            this.Memo10_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo11_txt
            // 
            this.Memo11_txt.Enabled = false;
            this.Memo11_txt.Location = new System.Drawing.Point(332, 285);
            this.Memo11_txt.Name = "Memo11_txt";
            this.Memo11_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo11_txt.TabIndex = 281;
            this.Memo11_txt.Tag = "11";
            this.Memo11_txt.Text = "memo 11";
            this.Memo11_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo12_txt
            // 
            this.Memo12_txt.Enabled = false;
            this.Memo12_txt.Location = new System.Drawing.Point(332, 311);
            this.Memo12_txt.Name = "Memo12_txt";
            this.Memo12_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo12_txt.TabIndex = 282;
            this.Memo12_txt.Tag = "12";
            this.Memo12_txt.Text = "memo 12";
            this.Memo12_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo13_txt
            // 
            this.Memo13_txt.Enabled = false;
            this.Memo13_txt.Location = new System.Drawing.Point(332, 337);
            this.Memo13_txt.Name = "Memo13_txt";
            this.Memo13_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo13_txt.TabIndex = 283;
            this.Memo13_txt.Tag = "13";
            this.Memo13_txt.Text = "memo 13";
            this.Memo13_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo14_txt
            // 
            this.Memo14_txt.Enabled = false;
            this.Memo14_txt.Location = new System.Drawing.Point(332, 363);
            this.Memo14_txt.Name = "Memo14_txt";
            this.Memo14_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo14_txt.TabIndex = 284;
            this.Memo14_txt.Tag = "14";
            this.Memo14_txt.Text = "memo 14";
            this.Memo14_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo15_txt
            // 
            this.Memo15_txt.Enabled = false;
            this.Memo15_txt.Location = new System.Drawing.Point(332, 389);
            this.Memo15_txt.Name = "Memo15_txt";
            this.Memo15_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo15_txt.TabIndex = 285;
            this.Memo15_txt.Tag = "15";
            this.Memo15_txt.Text = "memo 15";
            this.Memo15_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo16_txt
            // 
            this.Memo16_txt.Enabled = false;
            this.Memo16_txt.Location = new System.Drawing.Point(332, 415);
            this.Memo16_txt.Name = "Memo16_txt";
            this.Memo16_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo16_txt.TabIndex = 286;
            this.Memo16_txt.Tag = "16";
            this.Memo16_txt.Text = "memo 16";
            this.Memo16_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo17_txt
            // 
            this.Memo17_txt.Enabled = false;
            this.Memo17_txt.Location = new System.Drawing.Point(332, 441);
            this.Memo17_txt.Name = "Memo17_txt";
            this.Memo17_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo17_txt.TabIndex = 287;
            this.Memo17_txt.Tag = "17";
            this.Memo17_txt.Text = "memo 17";
            this.Memo17_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo18_txt
            // 
            this.Memo18_txt.Enabled = false;
            this.Memo18_txt.Location = new System.Drawing.Point(332, 467);
            this.Memo18_txt.Name = "Memo18_txt";
            this.Memo18_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo18_txt.TabIndex = 288;
            this.Memo18_txt.Tag = "18";
            this.Memo18_txt.Text = "memo 18";
            this.Memo18_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo19_txt
            // 
            this.Memo19_txt.Enabled = false;
            this.Memo19_txt.Location = new System.Drawing.Point(332, 493);
            this.Memo19_txt.Name = "Memo19_txt";
            this.Memo19_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo19_txt.TabIndex = 289;
            this.Memo19_txt.Tag = "19";
            this.Memo19_txt.Text = "memo 19";
            this.Memo19_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Memo20_txt
            // 
            this.Memo20_txt.Enabled = false;
            this.Memo20_txt.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Memo20_txt.Location = new System.Drawing.Point(332, 519);
            this.Memo20_txt.Name = "Memo20_txt";
            this.Memo20_txt.Size = new System.Drawing.Size(276, 19);
            this.Memo20_txt.TabIndex = 290;
            this.Memo20_txt.Tag = "20";
            this.Memo20_txt.Text = "memo 20";
            this.Memo20_txt.TextChanged += new System.EventHandler(this.Memo_txt_TextChanged);
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_C_pb.Image = global::USB_IR_REMOCON_CT.Properties.Resources.ON;
            this.Status_C_pb.Location = new System.Drawing.Point(843, 549);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_NC_pb.Image = global::USB_IR_REMOCON_CT.Properties.Resources.OFF;
            this.Status_NC_pb.Location = new System.Drawing.Point(843, 549);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 8);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // BackGround_pb
            // 
            this.BackGround_pb.BackColor = System.Drawing.Color.White;
            this.BackGround_pb.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackGround_pb.BackgroundImage")));
            this.BackGround_pb.Location = new System.Drawing.Point(0, 0);
            this.BackGround_pb.Name = "BackGround_pb";
            this.BackGround_pb.Size = new System.Drawing.Size(878, 561);
            this.BackGround_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.BackGround_pb.TabIndex = 163;
            this.BackGround_pb.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(877, 560);
            this.Controls.Add(this.Memo20_txt);
            this.Controls.Add(this.Memo19_txt);
            this.Controls.Add(this.Memo18_txt);
            this.Controls.Add(this.Memo17_txt);
            this.Controls.Add(this.Memo16_txt);
            this.Controls.Add(this.Memo15_txt);
            this.Controls.Add(this.Memo14_txt);
            this.Controls.Add(this.Memo13_txt);
            this.Controls.Add(this.Memo12_txt);
            this.Controls.Add(this.Memo11_txt);
            this.Controls.Add(this.Memo10_txt);
            this.Controls.Add(this.Memo09_txt);
            this.Controls.Add(this.Memo08_txt);
            this.Controls.Add(this.Memo07_txt);
            this.Controls.Add(this.Memo06_txt);
            this.Controls.Add(this.Memo05_txt);
            this.Controls.Add(this.Memo04_txt);
            this.Controls.Add(this.Memo03_txt);
            this.Controls.Add(this.Memo02_txt);
            this.Controls.Add(this.Memo01_txt);
            this.Controls.Add(this.Rec_btn_20);
            this.Controls.Add(this.Rec_btn_19);
            this.Controls.Add(this.Rec_btn_18);
            this.Controls.Add(this.Rec_btn_17);
            this.Controls.Add(this.Rec_btn_16);
            this.Controls.Add(this.Rec_btn_15);
            this.Controls.Add(this.Rec_btn_14);
            this.Controls.Add(this.Rec_btn_13);
            this.Controls.Add(this.Rec_btn_12);
            this.Controls.Add(this.Rec_btn_11);
            this.Controls.Add(this.Rec_btn_10);
            this.Controls.Add(this.Rec_btn_09);
            this.Controls.Add(this.Rec_btn_08);
            this.Controls.Add(this.Rec_btn_07);
            this.Controls.Add(this.Rec_btn_06);
            this.Controls.Add(this.Rec_btn_05);
            this.Controls.Add(this.Rec_btn_04);
            this.Controls.Add(this.Rec_btn_03);
            this.Controls.Add(this.Rec_btn_02);
            this.Controls.Add(this.Rec_btn_01);
            this.Controls.Add(this.Code_20);
            this.Controls.Add(this.Code_19);
            this.Controls.Add(this.Code_18);
            this.Controls.Add(this.Code_17);
            this.Controls.Add(this.Code_16);
            this.Controls.Add(this.Code_15);
            this.Controls.Add(this.Code_14);
            this.Controls.Add(this.Code_13);
            this.Controls.Add(this.Code_12);
            this.Controls.Add(this.Code_11);
            this.Controls.Add(this.Code_10);
            this.Controls.Add(this.Code_09);
            this.Controls.Add(this.Code_08);
            this.Controls.Add(this.Code_07);
            this.Controls.Add(this.Code_06);
            this.Controls.Add(this.Code_05);
            this.Controls.Add(this.Code_04);
            this.Controls.Add(this.Code_03);
            this.Controls.Add(this.Code_02);
            this.Controls.Add(this.Code_01);
            this.Controls.Add(this.Area20_btn);
            this.Controls.Add(this.Area19_btn);
            this.Controls.Add(this.Area18_btn);
            this.Controls.Add(this.Area17_btn);
            this.Controls.Add(this.Area16_btn);
            this.Controls.Add(this.Area15_btn);
            this.Controls.Add(this.Area14_btn);
            this.Controls.Add(this.Area13_btn);
            this.Controls.Add(this.Area12_btn);
            this.Controls.Add(this.Area11_btn);
            this.Controls.Add(this.Area10_btn);
            this.Controls.Add(this.Area09_btn);
            this.Controls.Add(this.Area08_btn);
            this.Controls.Add(this.Area07_btn);
            this.Controls.Add(this.Area06_btn);
            this.Controls.Add(this.Area05_btn);
            this.Controls.Add(this.Area04_btn);
            this.Controls.Add(this.Area03_btn);
            this.Controls.Add(this.Area02_btn);
            this.Controls.Add(this.Area01_btn);
            this.Controls.Add(this.Code_lbl);
            this.Controls.Add(this.Debug_label5);
            this.Controls.Add(this.Debug_label4);
            this.Controls.Add(this.Debug_label3);
            this.Controls.Add(this.Debug_label2);
            this.Controls.Add(this.Debug_label1);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.Status_NC_pb);
            this.Controls.Add(this.BackGround_pb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(887, 596);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "USB�ԊO�������R���L�b�g ���M�ݒ�, Configuration Tool ver 1.00";
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BackGround_pb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.Label Debug_label1;
        private System.Windows.Forms.Label Debug_label2;
        private System.Windows.Forms.Label Debug_label3;
        private System.Windows.Forms.Label Debug_label4;
        private System.Windows.Forms.Label Debug_label5;
        private System.Windows.Forms.Label Code_lbl;
        private System.Windows.Forms.Button Area01_btn;
        private System.Windows.Forms.Button Area02_btn;
        private System.Windows.Forms.Button Area03_btn;
        private System.Windows.Forms.Button Area04_btn;
        private System.Windows.Forms.Button Area05_btn;
        private System.Windows.Forms.Button Area06_btn;
        private System.Windows.Forms.Button Area07_btn;
        private System.Windows.Forms.Button Area08_btn;
        private System.Windows.Forms.Button Area09_btn;
        private System.Windows.Forms.Button Area10_btn;
        private System.Windows.Forms.Button Area11_btn;
        private System.Windows.Forms.Button Area12_btn;
        private System.Windows.Forms.Button Area13_btn;
        private System.Windows.Forms.Button Area14_btn;
        private System.Windows.Forms.Button Area15_btn;
        private System.Windows.Forms.Button Area16_btn;
        private System.Windows.Forms.Button Area17_btn;
        private System.Windows.Forms.Button Area18_btn;
        private System.Windows.Forms.Button Area19_btn;
        private System.Windows.Forms.Button Area20_btn;
        private System.Windows.Forms.Label Code_20;
        private System.Windows.Forms.Label Code_19;
        private System.Windows.Forms.Label Code_18;
        private System.Windows.Forms.Label Code_17;
        private System.Windows.Forms.Label Code_16;
        private System.Windows.Forms.Label Code_15;
        private System.Windows.Forms.Label Code_14;
        private System.Windows.Forms.Label Code_13;
        private System.Windows.Forms.Label Code_12;
        private System.Windows.Forms.Label Code_11;
        private System.Windows.Forms.Label Code_10;
        private System.Windows.Forms.Label Code_09;
        private System.Windows.Forms.Label Code_08;
        private System.Windows.Forms.Label Code_07;
        private System.Windows.Forms.Label Code_06;
        private System.Windows.Forms.Label Code_05;
        private System.Windows.Forms.Label Code_04;
        private System.Windows.Forms.Label Code_03;
        private System.Windows.Forms.Label Code_02;
        private System.Windows.Forms.Label Code_01;
        private System.Windows.Forms.Button Rec_btn_03;
        private System.Windows.Forms.Button Rec_btn_02;
        private System.Windows.Forms.Button Rec_btn_01;
        private System.Windows.Forms.Button Rec_btn_06;
        private System.Windows.Forms.Button Rec_btn_05;
        private System.Windows.Forms.Button Rec_btn_04;
        private System.Windows.Forms.Button Rec_btn_09;
        private System.Windows.Forms.Button Rec_btn_08;
        private System.Windows.Forms.Button Rec_btn_07;
        private System.Windows.Forms.Button Rec_btn_12;
        private System.Windows.Forms.Button Rec_btn_11;
        private System.Windows.Forms.Button Rec_btn_10;
        private System.Windows.Forms.Button Rec_btn_15;
        private System.Windows.Forms.Button Rec_btn_14;
        private System.Windows.Forms.Button Rec_btn_13;
        private System.Windows.Forms.Button Rec_btn_18;
        private System.Windows.Forms.Button Rec_btn_17;
        private System.Windows.Forms.Button Rec_btn_16;
        private System.Windows.Forms.Button Rec_btn_20;
        private System.Windows.Forms.Button Rec_btn_19;
        private System.Windows.Forms.TextBox Memo01_txt;
        private System.Windows.Forms.TextBox Memo02_txt;
        private System.Windows.Forms.TextBox Memo03_txt;
        private System.Windows.Forms.TextBox Memo04_txt;
        private System.Windows.Forms.TextBox Memo05_txt;
        private System.Windows.Forms.TextBox Memo06_txt;
        private System.Windows.Forms.TextBox Memo07_txt;
        private System.Windows.Forms.TextBox Memo08_txt;
        private System.Windows.Forms.TextBox Memo09_txt;
        private System.Windows.Forms.TextBox Memo10_txt;
        private System.Windows.Forms.TextBox Memo11_txt;
        private System.Windows.Forms.TextBox Memo12_txt;
        private System.Windows.Forms.TextBox Memo13_txt;
        private System.Windows.Forms.TextBox Memo14_txt;
        private System.Windows.Forms.TextBox Memo15_txt;
        private System.Windows.Forms.TextBox Memo16_txt;
        private System.Windows.Forms.TextBox Memo17_txt;
        private System.Windows.Forms.TextBox Memo18_txt;
        private System.Windows.Forms.TextBox Memo19_txt;
        private System.Windows.Forms.PictureBox BackGround_pb;
        private System.Windows.Forms.TextBox Memo20_txt;
    }
}


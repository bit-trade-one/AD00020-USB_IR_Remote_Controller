﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.send_btn = New System.Windows.Forms.Button
        Me.send_ex_btn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'send_btn
        '
        Me.send_btn.Location = New System.Drawing.Point(37, 22)
        Me.send_btn.Name = "send_btn"
        Me.send_btn.Size = New System.Drawing.Size(200, 23)
        Me.send_btn.TabIndex = 0
        Me.send_btn.Text = "送信 [最大6バイト]"
        Me.send_btn.UseVisualStyleBackColor = True
        '
        'send_ex_btn
        '
        Me.send_ex_btn.Location = New System.Drawing.Point(256, 22)
        Me.send_ex_btn.Name = "send_ex_btn"
        Me.send_ex_btn.Size = New System.Drawing.Size(200, 23)
        Me.send_ex_btn.TabIndex = 1
        Me.send_ex_btn.Text = "拡張コード 送信 [最大32バイト]"
        Me.send_ex_btn.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 66)
        Me.Controls.Add(Me.send_ex_btn)
        Me.Controls.Add(Me.send_btn)
        Me.Name = "Form1"
        Me.Text = "USB赤外線リモコンキット　赤外線送信サンプル"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents send_btn As System.Windows.Forms.Button
    Friend WithEvents send_ex_btn As System.Windows.Forms.Button

End Class

﻿Imports USB_IR_Library
Imports Microsoft.Win32.SafeHandles

Public Class Form1

    Private Sub send_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles send_btn.Click

        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim code() As Byte = {&H13, &H8, &H0, &H0, &H0, &HFF}    ' 赤外線コード
        Dim i_ret As Integer = 0

        Try
            handle_usb_device = USBIR.openUSBIR(Me.Handle)
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEへ送信 パラメータ[USB DEVICEハンドル、フォーマットタイプ、送信赤外線コード、赤外線コードのビット長]
                i_ret = USBIR.writeUSBIR(handle_usb_device, USBIR.IR_FORMAT.SONY, code, 12)
                'i_ret = USBIR.writeUSBIR(handle_usb_device, USBIR.IR_FORMAT.AEHA, code, 48)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                i_ret = USBIR.closeUSBIR(handle_usb_device)
            End If
        End Try
    End Sub

    Private Sub send_ex_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles send_ex_btn.Click
        Dim handle_usb_device As SafeFileHandle = Nothing           ' USB DEVICEハンドル
        Dim code() As Byte = {&H1, &H2, &H3, &H4, &H5, &H6, &H7, &H8, _
                              &H9, &HA, &H11, &H12, &H13, &H14, &H15, &H16, _
                              &H17, &H18, &H19, &H1A, &HFF, &H0, &H0, &H0, _
                              &H0, &H0, &H0, &H0, &H0, &H0, &H0, &HFF}    ' 赤外線コード
        Dim i_ret As Integer = 0

        Try
            handle_usb_device = USBIR.openUSBIR(Me.Handle)
            If (Not handle_usb_device Is Nothing) Then
                ' USB DEVICEへ送信 パラメータ[USB DEVICEハンドル、フォーマットタイプ、送信赤外線コード、赤外線コードのビット長]
                i_ret = USBIR.writeUSBIRex(handle_usb_device, USBIR.IR_FORMAT.AEHA, code, 64, 96)
                'i_ret = USBIR.writeUSBIRex(handle_usb_device, USBIR.IR_FORMAT.AEHA, code, 64, 97)
            End If
        Catch ex As Exception
        Finally
            If (Not handle_usb_device Is Nothing) Then
                i_ret = USBIR.closeUSBIR(handle_usb_device)
            End If
        End Try
    End Sub
End Class

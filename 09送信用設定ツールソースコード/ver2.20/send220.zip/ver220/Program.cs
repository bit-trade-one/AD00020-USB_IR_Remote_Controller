using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace HID_PnP_Demo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            ////���[�J���R���s���[�^��Ŏ��s����Ă��邷�ׂẴv���Z�X���擾
            //System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcesses();
            //string myProcessName = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
            //int myProcessCnt = 0;
            //foreach (System.Diagnostics.Process p in ps)
            //{
            //    try
            //    {
            //        if (p.ProcessName.CompareTo(myProcessName) == 0
            //            || p.MainModule.ModuleName.IndexOf("REMOCON_CT_RECV.exe") >= 0
            //            || p.MainModule.ModuleName.IndexOf("REMOCON_CT_TRANS.exe") >= 0)
            //        {
            //            myProcessCnt++;
            //        }
            //    }
            //    catch
            //    {
            //    }
            //}
            //if (myProcessCnt >= 2)
            //{
            //    //���łɋN�����Ă���Ɣ��f���ďI��
            //    MessageBox.Show("���d�N���͂ł��܂���B");
            //    return;
            //}


            Application.Run(new Form1());
        }
    }
}